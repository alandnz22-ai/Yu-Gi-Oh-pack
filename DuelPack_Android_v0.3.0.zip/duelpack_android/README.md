# DuelPack Android — protótipo 0.2.0

Protótipo offline de abertura cinematográfica de pacotes e coleção de cartas para Android, com interface em português.

## Novidades da versão 0.2.0
- Revelação de uma carta por vez, com suspense e animações 3D.
- Brilho holográfico animado e destaque visual para raridades altas.
- Efeitos sonoros sintetizados localmente, com botão para ligar/desligar.
- Animação de selo/pacote e resumo ao final da abertura.
- Inventário, moedas e progresso continuam salvos localmente no WebView.

## O que está incluído
- Saldo inicial de 1000 moedas virtuais; pacote custa 100 e contém 5 cartas.
- Raridades: Comum, Rara, Super Rara, Ultra Rara e Secreta Rara.
- Busca, filtro por raridade, contadores e progresso da coleção.
- Sem conexão de rede, anúncios, compras reais ou conta online.

## Importante sobre artes e marcas
Esta é uma demonstração para coleção pessoal, mas não inclui artes oficiais. Os símbolos são provisórios. Para adicionar artes oficiais, use arquivos que você tenha direito de usar e mantenha-os localmente no projeto. A distribuição pública de conteúdo protegido pode exigir autorização dos titulares.

## Gerar APK no Android Studio
1. Instale Android Studio e JDK 17.
2. Abra a pasta `duelpack_android` no Android Studio.
3. Sincronize o projeto Gradle e instale Android SDK Platform 35 se solicitado.
4. Execute em um dispositivo Android ou emulador para testar.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

Este pacote contém o código-fonte; não é um APK compilado.


## v0.3 — moldura e holografia
- Cartas com moldura dourada detalhada e brilho holográfico animado.
- Suporte a imagens locais JPG, PNG e WebP em `app/src/main/assets/images/cards/`.
- Para ativar uma imagem, adicione `image: "images/cards/nome.webp"` ao objeto da carta em `index.html`.
- Sem imagem local, o protótipo mantém o símbolo provisório.
