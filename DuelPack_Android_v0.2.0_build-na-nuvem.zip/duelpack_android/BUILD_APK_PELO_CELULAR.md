# Como gerar o APK usando apenas o celular

Este projeto inclui um workflow do GitHub Actions para compilar o APK na nuvem.

1. Extraia o ZIP no celular.
2. No navegador, entre em https://github.com e crie uma conta ou entre na sua conta.
3. Crie um repositório novo. Se quiser manter o código menos exposto, escolha **Private**.
4. Envie os arquivos e pastas que estão dentro da pasta `duelpack_android` para a raiz do repositório (incluindo a pasta oculta `.github/workflows`). É importante que `settings.gradle`, `build.gradle`, `app/` e `.github/` fiquem na raiz do repositório.
5. Abra a aba **Actions** do repositório. Se solicitado, habilite Actions para o repositório.
6. Selecione **Build DuelPack APK** e toque em **Run workflow**. Se o envio dos arquivos já disparar o workflow, abra a execução mais recente.
7. Espere a execução terminar com sucesso. Na página da execução, encontre **Artifacts** e baixe `DuelPack-debug-APK`.
8. Extraia o arquivo baixado para encontrar `app-debug.apk` e toque nele para instalar. O Android pode pedir que você autorize o navegador ou gerenciador de arquivos a instalar apps desconhecidos.

Observações:
- A compilação exige internet e uma conta GitHub, mas não exige computador.
- O APK de depuração é para testes e não é uma versão publicada na Play Store.
- Não envie senhas, chaves privadas ou dados pessoais para o repositório.
